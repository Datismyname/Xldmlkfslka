package com.syana.saudi.syanh

class ComList {

    var name:String? = null
    var image:Int? = null

    constructor(name:String, image:Int){
        this.name = name
        this.image = image
    }


}