package com.syana.saudi.syanh

class OrdersList{

    var name:String? = null
    var title:String? = null
    var subTitle:String? = null

    constructor(name:String,title:String, subTitle:String){
        this.name = name
        this.title = title
        this.subTitle = subTitle

    }




}