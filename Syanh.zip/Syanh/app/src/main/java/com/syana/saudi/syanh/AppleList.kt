package com.syana.saudi.syanh

class AppleList{

    var title:String?= null
    var image:Int? = null

    constructor(title: String, image: Int){
        this.title = title
        this.image = image
    }



}