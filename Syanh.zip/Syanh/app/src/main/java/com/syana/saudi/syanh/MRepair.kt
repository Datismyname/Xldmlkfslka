package com.syana.saudi.syanh

class MRepair {

    var title:String?=null
    var description:String?=null
    var image:Int?=null


    constructor(title:String, description:String, image:Int){
        this.title = title
        this.description = description
        this.image = image
    }



}